import mysql.connector
import sys
from prettytable import PrettyTable

db = mysql.connector.connect(
    host = 'localhost',
    user = 'root',
    password = 'graduation',
    database = 'project'
)
mycursor = db.cursor()


def execute_sql_query(query):
  table = PrettyTable()
  mycursor.execute(query)
  myresult = mycursor.fetchall()
  lst = []
  table.add_row(tuple(range(10)))
  # for x in myresult:
    # table.add_row(x)
  return str(table)
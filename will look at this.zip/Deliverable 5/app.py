from flask import Flask, render_template, request
from main import execute_sql_query

app = Flask(__name__)
lst = execute_sql_query("select * from user")

@app.route("/", methods = ['POST', 'GET'])
def home():
    if request.method == "POST":
        name = request.form.get("username")  
        return render_template("index.html", name = str(lst))
    return render_template("index.html")

@app.route("/create")
def create():
    return render_template('create.html')

@app.route("/read")
def read():
    return render_template('read.html')

@app.route("/update")
def update():
    return render_template('update.html')

@app.route("/delete")
def delete():
    return render_template('delete.html')

if __name__ == '__main__':
    app.run(debug=True)
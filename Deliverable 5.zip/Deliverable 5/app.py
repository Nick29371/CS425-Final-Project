from flask import Flask, render_template, request
import main

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/query")
def create():
    return render_template('table.html', message = 'Enter SQL Command')

@app.route("/table", methods = ["GET"])
def table():
    if request.method == 'GET':
        query = request.args["query"]
        main.refresh(query)
        return render_template("results.html")
    else:
        return render_template("table.html")


if __name__ == '__main__':
    app.run(debug=True)
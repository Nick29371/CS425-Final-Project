import mysql.connector
import pandas as pd

db = mysql.connector.connect(
    host = 'localhost',
    user = 'root',
    password = 'graduation',
    database = 'project'
)
mycursor = db.cursor()


def execute_sql_query(query):
  mycursor.execute(query)
  myresult = mycursor.fetchall()
  return myresult

def refresh(message):
  df = pd.DataFrame()
  for x in execute_sql_query(message):
    df2 = pd.DataFrame(list(x)).T
    df = pd.concat([df,df2])
  df.to_html("templates/results.html")
  return

def pick_table():
  lst = []
  i = 0
  for x in execute_sql_query('show tables'):
    lst.append((x,i))
    i += 1
  return str(lst)
